# 🎮 THE IMPOSTER.IO — APK Build Guide

## Method 1: Android Studio (Recommended — FREE)

### Step 1 — Install Android Studio
Download from: https://developer.android.com/studio
(It's free and installs everything automatically)

### Step 2 — Open this project
1. Open Android Studio
2. Click "Open" → select the `imposter-apk` folder
3. Wait for Gradle sync (takes 2-5 min first time)

### Step 3 — Build the APK
1. Menu → Build → Build Bundle(s)/APK(s) → Build APK(s)
2. Wait ~1 minute
3. Click "locate" in the popup
4. Your APK is at: `app/build/outputs/apk/debug/app-debug.apk`

### Step 4 — Install on phone
- Enable "Install from unknown sources" in Android Settings → Security
- Transfer APK to phone via USB / WhatsApp / Google Drive
- Tap the APK file to install

---

## Method 2: Online — Gonative.io (Zero setup, easiest)

1. Host your `index.html` on GitHub Pages (free):
   - Create GitHub account → New repo → Upload `imposter-io.html` → rename to `index.html`
   - Go to Settings → Pages → Enable
   - Your URL: `https://yourusername.github.io/reponame`

2. Go to https://gonative.io
3. Enter your GitHub Pages URL
4. Download APK directly — no coding needed!

---

## Method 3: PWA (Install like an app — no APK needed!)

Your game already works as a PWA. Just:
1. Host `index.html` on GitHub Pages or Netlify
2. Open in Chrome on Android
3. Tap the 3-dot menu → "Add to Home Screen"
4. It installs like a real app with full screen!

---

## Project Structure
```
imposter-apk/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/www/
│       │   └── index.html          ← YOUR GAME
│       ├── java/io/imposter/game/
│       │   └── MainActivity.java   ← WebView wrapper
│       └── res/
│           ├── drawable/ic_launcher.png
│           └── values/
│               ├── strings.xml
│               └── styles.xml
├── build.gradle
└── settings.gradle
```

## App Details
- Package: io.imposter.game
- Min Android: 5.0 (API 21) — supports 98% of devices
- Target: Android 14 (API 34)
- Orientation: Portrait
- Full screen: Yes (immersive mode)
- Internet: Required for Firebase multiplayer
